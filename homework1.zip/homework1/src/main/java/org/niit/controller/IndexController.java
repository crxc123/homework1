package org.niit.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class IndexController {
	
	@RequestMapping("/index/{id}")
	public String index(@RequestParam("name") String name,@PathVariable("id") String id
			,Map<String,String> ojbs) {
		int m=1;
		m=m/0;
		System.out.println("the name is "+name);
		System.out.println("the id is "+m);
		ojbs.put("info", "world!");
		System.out.println("m = "+m);
		
		return "/WEB-INF/jsps/index.jsp";
	}
}
